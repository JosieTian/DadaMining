# Using Five Fold Cross Validation to generate five sets data that each set contains 204 test data and 820 train data

import pandas as pd
import random as rd

dataset = pd.read_excel("C:/Users/Flamingo_Hot/PycharmProjects/pythonProject-midterm/heart.xlsx")

gk = dataset.groupby('target')
class_P = gk.get_group(1)
cp = rd.sample(range(0, class_P.shape[0]), class_P.shape[0])
p_fold_size = int(class_P.shape[0]/5)
cp1 = cp[0:int(class_P.shape[0] / 5)]
cp2 = cp[p_fold_size:p_fold_size * 2]
cp3 = cp[p_fold_size * 2: p_fold_size * 3]
cp4 = cp[p_fold_size * 3: p_fold_size * 4]
cp5 = cp[p_fold_size * 4: class_P.shape[0]]
P_1 = class_P.iloc[cp1, :]
P_2 = class_P.iloc[cp2, :]
P_3 = class_P.iloc[cp3, :]
P_4 = class_P.iloc[cp4, :]
P_5 = class_P.iloc[cp5, :]

class_N = gk.get_group(0)
cn = rd.sample(range(0, class_N.shape[0]), class_N.shape[0])
n_fold_size = int(class_N.shape[0] / 5)
# seperate into 5 fold
cn1 = cn[0:n_fold_size]
cn2 = cn[n_fold_size:n_fold_size * 2]
cn3 = cn[n_fold_size * 2: n_fold_size * 3]
cn4 = cn[n_fold_size * 3: n_fold_size * 4]
cn5 = cn[n_fold_size * 4: class_N.shape[0]]
N_1 = class_N.iloc[cn1, :]
N_2 = class_N.iloc[cn2, :]
N_3 = class_N.iloc[cn3, :]
N_4 = class_N.iloc[cn4, :]
N_5 = class_N.iloc[cn5, :]

# !!first folding
# combine into training dataset
train_data1 = pd.concat([P_2, P_3, P_4, P_5, N_2, N_3, N_4, N_5], ignore_index=True)
# shuffle the whole training dataset
train1 = rd.sample(range(0, train_data1.shape[0]), train_data1.shape[0])
train_data1 = train_data1.iloc[train1, :]
# print(train_data1)
# combine testing dataset
test_data1 = pd.concat([P_1, N_1], ignore_index=True)
# shuffle the whole testing dataset
test1 = rd.sample(range(0, test_data1.shape[0]), test_data1.shape[0])
test_data1 = test_data1.iloc[test1, :]

# !!second folding
train_data2 = pd.concat([P_1, P_3, P_4, P_5, N_1, N_3, N_4, N_5], ignore_index=True)
# shuffle the whole training dataset
train2 = rd.sample(range(0, train_data2.shape[0]), train_data2.shape[0])
train_data2 = train_data2.iloc[train2, :]
# combine testing dataset
test_data2 = pd.concat([P_2, N_2], ignore_index=True)
# shuffle the whole testing dataset
test2 = rd.sample(range(0, test_data2.shape[0]), test_data2.shape[0])
test_data2 = test_data2.iloc[test2, :]

# !!third folding
train_data3 = pd.concat([P_1, P_2, P_4, P_5, N_1, N_2, N_4, N_5], ignore_index=True)
# shuffle the whole training dataset
train3 = rd.sample(range(0, train_data3.shape[0]), train_data3.shape[0])
train_data3 = train_data3.iloc[train3, :]
# combine testing dataset
test_data3 = pd.concat([P_3, N_3], ignore_index=True)
# shuffle the whole testing dataset
test3 = rd.sample(range(0, test_data3.shape[0]), test_data3.shape[0])
test_data3 = test_data3.iloc[test3, :]

# !!fourth folding
train_data4 = pd.concat([P_1, P_2, P_3, P_5, N_1, N_2, N_3, N_5], ignore_index=True)
# shuffle the whole training dataset
train4 = rd.sample(range(0, train_data4.shape[0]), train_data4.shape[0])
train_data4 = train_data4.iloc[train4, :]
# combine testing dataset
test_data4 = pd.concat([P_4, N_4], ignore_index=True)
# shuffle the whole testing dataset
test4 = rd.sample(range(0, test_data4.shape[0]), test_data4.shape[0])
test_data4 = test_data4.iloc[test4, :]

# !!fifth folding
train_data5 = pd.concat([P_1, P_2, P_3, P_4, N_1, N_2, N_3, N_4], ignore_index=True)
# shuffle the whole training dataset
train5 = rd.sample(range(0, train_data5.shape[0]), train_data5.shape[0])
train_data5 = train_data5.iloc[train5, :]
# combine testing dataset
test_data5 = pd.concat([P_5, N_5], ignore_index=True)
# shuffle the whole testing dataset
test5 = rd.sample(range(0, test_data5.shape[0]), test_data5.shape[0])
test_data5 = test_data5.iloc[test5, :]

train_data1.to_excel("train1.xlsx")
train_data2.to_excel("train2.xlsx")
train_data3.to_excel("train3.xlsx")
train_data4.to_excel("train4.xlsx")
train_data5.to_excel("train5.xlsx")
test_data1.to_excel("test1.xlsx")
test_data2.to_excel("test2.xlsx")
test_data3.to_excel("test3.xlsx")
test_data4.to_excel("test4.xlsx")
test_data5.to_excel("test5.xlsx")