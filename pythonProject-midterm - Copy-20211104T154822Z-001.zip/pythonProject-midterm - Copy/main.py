# Preprocessing Dataset
# Expanding dataset from 14 attributes to 40 attributes

import xlrd
import pandas as pd
import openpyxl
import string
from string import digits
import xlwt
import pip

file = "C:/Users/Flamingo_Hot/PycharmProjects/pythonProject-midterm/venv/heart.xls"
file1 = xlrd.open_workbook(file)
file2 = file1.sheet_by_index(0)


a50 = 0
a50to60 = 0
a60 = 0

age = ["age<=50", "50<age>=60", "age>60"]
df1 = pd.DataFrame(columns=age, index=None)
for i in range(1, file2.nrows):
    if int(file2.cell_value(i, 0)) <= 50:
        a50 = a50+1
        df1._set_value(i+1, 'age<=50', 1)
    elif int(file2.cell_value(i, 0)) <= 60:
        a50to60 = a50to60+1
        df1._set_value(i + 1, '50<age>=60', 1)
    elif int(file2.cell_value(i, 0)) > 60:
        a60 = a60+1
        df1._set_value(i + 1, 'age>60', 1)

print("age <= 50:       " + str(a50))
print("50 < age >= 60:  " + str(a50to60))
print("age > 60:        " + str(a60))
#df1.to_excel("age.xlsx")

cp = ["CP0", "CP1", "CP2", "CP3"]
cp0 = 0
cp1 = 0
cp2 = 0
cp3 = 0
df2 = pd.DataFrame(columns=cp, index=None)
for i in range(1, file2.nrows):
    if int(file2.cell_value(i, 2)) == 0:
        cp0 = cp0+1
        df2._set_value(i+1, 'CP0', 1)
    elif int(file2.cell_value(i, 2)) == 1:
        cp1 = cp1+1
        df2._set_value(i + 1, 'CP1', 1)
    elif int(file2.cell_value(i, 2)) == 2:
        cp2 = cp2+1
        df2._set_value(i + 1, 'CP2', 1)
    elif int(file2.cell_value(i, 2)) == 3:
        cp3 = cp3 + 1
        df2._set_value(i + 1, 'CP3', 1)

print("cp0: " + str(cp0))
print("cp1: " + str(cp1))
print("cp2: " + str(cp2))
print("cp3: " + str(cp3))
print(df2)

res = pd.concat([df1, df2], axis=1, join='inner')

trestbps120 = 0
trestbps120to140 = 0
trestbps140 = 0
trestbps = ["trestbps<=120", "trestbps120to140", "trestbps>=140"]
df3 = pd.DataFrame(columns=trestbps, index=None)
for i in range(1, file2.nrows):
    if int(file2.cell_value(i, 3)) <= 120:
        trestbps120 = trestbps120+1
        df3._set_value(i+1, 'trestbps<=120', 1)
    elif int(file2.cell_value(i, 3)) < 140:
        trestbps120to140 = trestbps120to140+1
        df3._set_value(i + 1, 'trestbps120to140', 1)
    elif int(file2.cell_value(i, 3)) >= 140:
        trestbps140 = trestbps140+1
        df3._set_value(i + 1, 'trestbps>=140', 1)

print("trestbps<=120:     " + str(trestbps120))
print("120<trestbps<140:  " + str(trestbps120to140))
print("trestbps>=120:     " + str(trestbps140))

res = pd.concat([res, df3], axis=1, join='inner')
print(res)

chol = ["chol<=210", "chol210to290", "chol>=290"]
chol210 = 0
chol210to290 = 0
chol290 = 0
df4 = pd.DataFrame(columns=chol, index=None)
for i in range(1, file2.nrows):
    if int(file2.cell_value(i, 4)) <= 210:
        chol210 = chol210+1
        df4._set_value(i+1, 'chol<=210', 1)
    elif int(file2.cell_value(i, 4)) < 290:
        chol210to290 = chol210to290+1
        df4._set_value(i + 1, 'chol210to290', 1)
    elif int(file2.cell_value(i, 4)) >= 290:
        chol290 = chol290+1
        df4._set_value(i + 1, 'chol>=290', 1)

print("chol<=210:      " + str(chol210))
print("210<chol<290:   " + str(chol210to290))
print("chol>=290:      " + str(chol290))

res = pd.concat([res, df4], axis=1, join='inner')

restecg = ["restecg0", "restecg1", "restecg2"]
restecg0 = 0
restecg1 = 0
restecg2 = 0
df5 = pd.DataFrame(columns=restecg, index=None)
for i in range(1, file2.nrows):
    if int(file2.cell_value(i, 6)) == 0:
        restecg0 = restecg0+1
        df5._set_value(i+1, 'restecg0', 1)
    elif int(file2.cell_value(i, 6)) == 1:
        restecg1 = restecg1+1
        df5._set_value(i + 1, 'restecg1', 1)
    elif int(file2.cell_value(i, 6)) == 2:
        restecg2 = restecg2+1
        df5._set_value(i + 1, 'restecg2', 1)

print("restecg0: " + str(restecg0))
print("restecg1: " + str(restecg1))
print("restecg2: " + str(restecg2))

res = pd.concat([res, df5], axis=1, join='inner')

thalach = ["thalach<=120", "120<thalach<140", "140<=thalach<160", "160<=thalach<180", "thalach>=180"]
tha120 = 0
tha120to140 = 0
tha140to160 = 0
tha160to180 = 0
tha180 = 0
df6 = pd.DataFrame(columns=thalach, index=None)
for i in range(1, file2.nrows):
    if int(file2.cell_value(i, 7)) <= 120:
        tha120 = tha120+1
        df6._set_value(i+1, 'thalach<=120', 1)
    elif int(file2.cell_value(i, 7)) < 140:
        tha120to140 = tha120to140+1
        df6._set_value(i + 1, '120<thalach<140', 1)
    elif int(file2.cell_value(i, 7)) <160:
        tha140to160 = tha140to160+1
        df6._set_value(i + 1, '140<=thalach<160', 1)
    elif int(file2.cell_value(i, 7)) <180:
        tha160to180 = tha160to180 + 1
        df6._set_value(i + 1, '160<=thalach<180', 1)
    elif int(file2.cell_value(i, 7)) >=180:
        tha180 = tha180 + 1
        df6._set_value(i + 1, 'thalach>=180', 1)

print("thalach<=120:        " + str(tha120))
print("120<thalach<140:     " + str(tha120to140))
print("140<=thalach<160:    " + str(tha140to160))
print("160<=thalach<180:    " + str(tha160to180))
print("thalach>=180:        " + str(tha180))
res = pd.concat([res, df6], axis=1, join='inner')

oldpeak = ["oldpeak<0.4", "0.4<=oldpeak<0.8", "0.8<=oldpeak<1.6", "1.6<=oldpeak<3", "oldpeak>=3"]
o4 = 0
o8 = 0
o16 = 0
o3 = 0
o3more = 0
df7 = pd.DataFrame(columns=oldpeak, index=None)
for i in range(1, file2.nrows):
    if float(file2.cell_value(i, 9)) < 0.1:
        o4 = o4+1
        df7._set_value(i+1, 'oldpeak<0.4', 1)
    elif float(file2.cell_value(i, 9)) < 0.8:
        o8 = o8+1
        df7._set_value(i + 1, '0.4<=oldpeak<0.8', 1)
    elif float(file2.cell_value(i, 9)) < 1.6:
        o16 = o16+1
        df7._set_value(i + 1, '0.8<=oldpeak<1.6', 1)
    elif float(file2.cell_value(i, 9)) < 3:
        o3 = o3 + 1
        df7._set_value(i + 1, '1.6<=oldpeak<3', 1)
    elif float(file2.cell_value(i, 9)) >= 3:
        o3more = o3more + 1
        df7._set_value(i + 1, 'oldpeak>=3', 1)

print("oldpeak < 0.4:          " + str(o4))
print("0.4 <= oldpeak < 0.8:   " + str(o8))
print("0.8 <= oldpeak < 1.6:   " + str(o16))
print("1.6 <= oldpeak < 3:     " + str(o3))
print("oldpeak >= 3:           " + str(o3more))

res = pd.concat([res, df7], axis=1, join='inner')


slope = ["slope0", "slope1", "slope2"]
slope0 = 0
slope1 = 0
slope2 = 0
df8 = pd.DataFrame(columns=slope, index=None)
for i in range(1, file2.nrows):
    if int(file2.cell_value(i, 10)) == 0:
        slope0 = slope0+1
        df8._set_value(i+1, 'slope0', 1)
    elif int(file2.cell_value(i, 10)) == 1:
        slope1 = slope1+1
        df8._set_value(i + 1, 'slope1', 1)
    elif int(file2.cell_value(i, 10)) == 2:
        slope2 = slope2+1
        df8._set_value(i + 1, 'slope2', 1)
print("slope0 : " + str(slope0))
print("slope1 : " + str(slope1))
print("slope2 : " + str(slope2))
res = pd.concat([res, df8], axis=1, join='inner')


ca = ["CA0", "CA1", "CA2", "CA3", "CA4"]
ca0 = 0
ca1 = 0
ca2 = 0
ca3 = 0
ca4 = 0
df9 = pd.DataFrame(columns=ca, index=None)
for i in range(1, file2.nrows):
    if int(file2.cell_value(i, 11)) == 0:
        ca0 = ca0+1
        df9._set_value(i+1, 'CA0', 1)
    elif int(file2.cell_value(i, 11)) == 1:
        ca1 = ca1+1
        df9._set_value(i + 1, 'CA1', 1)
    elif int(file2.cell_value(i, 11)) == 2:
        ca2 = ca2+1
        df9._set_value(i + 1, 'CA2', 1)
    elif int(file2.cell_value(i, 11)) == 3:
        ca3 = ca3 + 1
        df9._set_value(i + 1, 'CA3', 1)
    elif int(file2.cell_value(i, 11)) == 4:
        ca4 = ca4 + 1
        df9._set_value(i + 1, 'CA4', 1)
print("ca0: " + str(ca0))
print("ca1: " + str(ca1))
print("ca2: " + str(ca2))
print("ca3: " + str(ca3))
print("ca4: " + str(ca4))
res = pd.concat([res, df9], axis=1, join='inner')


thal = ["thal1", "thal2", "thal3"]
thal1 = 0
thal2 = 0
thal3 = 0
df10 = pd.DataFrame(columns=thal, index=None)
for i in range(1, file2.nrows):
    if int(file2.cell_value(i, 12)) == 1:
        thal1 = thal1+1
        df10._set_value(i+1, 'thal1', 1)
    elif int(file2.cell_value(i, 12)) == 2:
        thal2 = thal2+1
        df10._set_value(i + 1, 'thal2', 1)
    elif int(file2.cell_value(i, 12)) == 3:
        thal3 = thal3+1
        df10._set_value(i + 1, 'thal3', 1)
print("thal1 : " + str(thal1))
print("thal2 : " + str(thal2))
print("thal3 : " + str(thal3))
res = pd.concat([res, df10], axis=1, join='inner')
print(res)


target = ["target"]
df11 = pd.DataFrame(columns=target, index=None)
fbs120less = 0
fbs120more = 0
for i in range(1, file2.nrows):
    if int(file2.cell_value(i, 13)) == 0:
        fbs120less = fbs120less+1
        df11._set_value(i + 1, 'target', 0)
    elif int(file2.cell_value(i, 13)) == 1:
        fbs120more = fbs120more+1
        df11._set_value(i + 1, 'target', 1)
print(df11)

res = pd.concat([df11, res], axis=1, join='inner')
print(res)

exang = ["exang"]
df12 = pd.DataFrame(columns=exang, index=None)
exang0 = 0
exang1 = 0
for i in range(1, file2.nrows):
    if int(file2.cell_value(i, 8)) == 0:
        exang0 = exang0+1
        df12._set_value(i + 1, 'exang', "")
    elif int(file2.cell_value(i, 8)) == 1:
        exang1 = exang1+1
        df12._set_value(i + 1, 'exang', 1)
print(df12)
res = pd.concat([res, df12], axis=1, join='inner')
print(res)


female = 0
male = 0
sex = ["sex"]
df13 = pd.DataFrame(columns=sex, index=None)
for i in range(1, file2.nrows):
    if int(file2.cell_value(i, 1)) == 0:
        female = female+1
        df13._set_value(i+1, 'sex', "")
    elif int(file2.cell_value(i, 1)) == 1:
        male = male+1
        df13._set_value(i+1 , 'sex', 1)
print(female)
print(male)
print(df13)
res = pd.concat([res, df13], axis=1, join='inner')
res.to_excel("heart.xlsx")
print(res.columns.values)