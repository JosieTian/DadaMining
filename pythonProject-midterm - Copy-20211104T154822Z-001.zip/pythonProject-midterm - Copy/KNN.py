# KNN algorithm and result metrics

import pandas as pd




def testAll(trainset, testset):
    result = []
    for i in range(testset.shape[0]):
        result.append(close_neighbors(trainset, testset.iloc[i]))
    return result

def close_neighbors(trainset, testset_row1):
    trainset_row1 = trainset.iloc[0]
    jaccard_distance(trainset_row1, testset_row1)
    predict_result = []
    for i in range(0, trainset.shape[0]):
        predict_result.append(jaccard_distance(testset_row1, trainset.iloc[i]))
    predict_result = sorted(enumerate(predict_result), key=lambda x: x[1], reverse=True)
    positive = 0
    negative = 0
    #the K value
    for i in range(0,9):
        index = predict_result[i][0]
        if trainset.iloc[index][0] == 1:
            positive += 1
        else:
            negative += 1
    if negative > positive:
        return 0
    else:
        return 1


def jaccard_distance(point1, point2):
    interset = 0
    union = 0
    for i in range(1, point1.shape[0]):
        if point1.iloc[i] == 1:
            if point2.iloc[i] == 1:
                interset += 1
            union += 1
        else:
            if point2.iloc[i] == 1:
                union += 1
    return interset/union

def evaluate_metric(predict_result, true_result):
    tp = 0
    tn = 0
    fp = 0
    fn = 0
    for i in range(len(predict_result)):
        if predict_result[i] == 1:
            if true_result[i] == 1:
                tp = tp+1
            else:
                fp = fp+1
        else:
            if true_result[i] == 0:
                tn = tn+1
            else:
                fn = fn+1
    accuracy = float((tp+tn) / len(predict_result))
    sensitivity = float(tp / (tp+fn))
    specificity = float(tn / (tn+fp))
    precision = float(tp / (tp+fp))

    print("     TP =", tp, "            Accuracy =", round(accuracy*100, 2), '%')
    print("     TN =", tn, "            Sensitivity =", round(sensitivity*100, 2), '%')
    print("     FP =", fp, "             Specificity =", round(specificity*100, 2), '%')
    print("     FN =", fn, "            Precision =", round(precision*100, 2), '%')

    print(tp)
    print(tn)
    print(fp)
    print(fn)

    print(round(accuracy*100, 2), '%')
    print(round(sensitivity*100, 2), '%')
    print(round(specificity*100, 2), '%')
    print(round(precision*100, 2), '%')

def main():
    train1 = "C:/Users/Flamingo_Hot/PycharmProjects/pythonProject-midterm/train1.xls"
    train1 = pd.read_excel(train1)
    train1 = train1.drop(train1.columns[0], axis=1)
    train1 = train1.drop(train1.columns[0], axis=1)
    test1 = "C:/Users/Flamingo_Hot/PycharmProjects/pythonProject-midterm/test1.xls"
    test1 = pd.read_excel(test1)
    test1 = test1.drop(test1.columns[0], axis=1)
    test1 = test1.drop(test1.columns[0], axis=1)

    predict_result = testAll(train1, test1)
    print(predict_result)
    true_result = test1.iloc[:, 0].values.tolist()
    print(true_result)
    evaluate_metric(predict_result, true_result)


main()