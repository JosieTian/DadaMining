# Convert the data from Excel formate to TXT formate

import pip
import xlrd
import xlwt
import pandas as pd
import openpyxl
import string
from string import digits

file = "C:/Users/Flamingo_Hot/PycharmProjects/pythonProject-midterm/train5.xls"
file1 = xlrd.open_workbook(file)
file2 = file1.sheet_by_index(0)
print(file2.cell_value(2,1))
print(file2.cell_value(2,4))
print(file2.cell_value(2,3))
print(file2.cell_value(1,2))
with open('trainf5.txt', 'w') as f:
    for i in range(1, file2.nrows):
        if int(file2.cell_value(i,2)) == 0:
            f.write("-1")
            f.write(" ")
        elif int(file2.cell_value(i,2)) != 0:
            f.write("1")
            f.write(" ")
        for j in range(3, file2.ncols):
            if file2.cell_value(i,j) == 1:
                f.write(str(j-2))
                f.write(":")
                f.write("1")
                f.write(" ")
            else:
                f.write(str(j-2))
                f.write(":")
                f.write("0")
                f.write(" ")
        f.write("\n")
