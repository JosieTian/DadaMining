# SVM results metrics

import pandas as pd
import sys
import fileinput
import re

a=[]
predlist=[]
actulist=[]

predictFile='prediction500.txt'
actualFile='file5.txt'

with open(predictFile) as f:
    lines = f.readlines()
    for line in lines:
        line=line.replace('\n','')
        a.append(line)

for i in range(len(a)):
    if float(a[i]) < 0:
        predlist.append(-1)
    elif float(a[i]) > 0:
        predlist.append(1)

with open(actualFile) as fl:
    lines=fl.readlines()
    for line in lines:
        first = line.split(' ', 1)[0]
        if int(first) == -1:
            actulist.append(-1)
        elif int(first) == 1:
            actulist.append(1)

tp=0
tn=0
fp=0
fn=0

for i in range(len(predlist)):
    if predlist[i] == -1:
        if predlist[i] == actulist[i]:
            tn = tn+1
        elif predlist[i] != actulist[i]:
            fn = fn+1
    elif predlist[i] == 1:
        if predlist[i] == actulist[i]:
            tp = tp+1
        elif predlist[i] != actulist[i]:
            fp = fp+1

acc=(tp+tn)/(tp+fp+fn+tn)*100
sen=tp/(tp+fn)*100
spe=tn/(tn+fn)*100
pre=tp/(tp+fp)*100
rec=tp/(tp+fn)*100
print("     TP =", tp, "            Accuracy =", round(acc,2), '%')
print("     TN =", tn, "            Sensitivity =", round(sen,2), '%')
print("     FP =", fp, "             Specificity =", round(spe,2), '%')
print("     FN =", fn, "            Precision =", round(pre,2), '%')
print("                              Recall =", round(rec,2), '%')


#Average Calculation
tp=(91+82+98+90+88)/5
tn=(85+85+88+88+92)/5
fp=(14+14+11+11+4)/5
fn=(13+22+6+14+19)/5
acc=(89.66+83.74+89.66+86.21+83.98)/5
sen=(93.27+83.65+93.27+82.69+82.24)/5
spe=(85.86+83.84+85.86+89.9+85.86)/5
pre=(87.39+84.47+87.39+89.58+86.27)/5
#rec=(90.38+92.31+91.35+89.42+85.05)/5
print("     TP =", tp, "            Accuracy =", round(acc,2), '%')
print("     TN =", tn, "            Sensitivity =", round(sen,2), '%')
print("     FP =", fp, "             Specificity =", round(spe,2), '%')
print("     FN =", fn, "            Precision =", round(pre,2), '%')
#print("                              Recall =", round(rec,2), '%')


