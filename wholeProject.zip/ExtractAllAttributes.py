import pip
import xlrd
import xlwt
import pandas as pd
import openpyxl
import string
from string import digits

# this is the computational wine wheel
wineName = "C:/Users/Flamingo_Hot/PycharmProjects/pythonProject4/wineName.xls"
# this is the reviews of Robert Parker
RP = "C:/Users/Flamingo_Hot/PycharmProjects/pythonProject6/Robert_Parker_Review.xls"
# this is the review of Wine Spectator
WS = "C:/Users/Flamingo_Hot/PycharmProjects/pythonProject6/Wine_Spectator_Review.xls"
AttributeNames = xlrd.open_workbook(wineName)
RPReview = xlrd.open_workbook(RP)
WSReview = xlrd.open_workbook(WS)
RPComment = RPReview.sheet_by_index(0)
WSComment = WSReview.sheet_by_index(0)
wName = AttributeNames.sheet_by_index(0)
# This is the sorted Normalized name
cols1 = list(set(wName.col_values(3, 1, wName.nrows)))
# This is the wine name and year combination
winecolR = RPComment.col_values(0, 1, RPComment.nrows)
winecolW = WSComment.col_values(0, 1, WSComment.nrows)
# This is the dataframe to hold RP attribute results
df_RP = pd.DataFrame(columns=cols1, index=winecolR)
df_WS = pd.DataFrame(columns=cols1, index=winecolW)
# These are the dataframes to hold words counting
attr_RP = pd.DataFrame(columns=[4, 5], index=winecolR)
attr_WS = pd.DataFrame(columns=[4, 5], index=winecolR)
# These are the CATEGORY and SUBCATEGORY attributes
category = ['FLORAL', 'FRUITY', 'OVERALL', 'SPICY', 'CHEMICAL', 'CARAMEL', 'MICROBIOLOGICAL', 'NUTTY', 'MEAT',
            'OXIDIZED', 'EARTHY', 'PUNGENT', 'HERBS/VEGETABLES', 'WOODY']
subcategory = ['DRIED', 'COOL', 'MEAT', 'FRUIT', 'TREE FRUIT', 'PHENOLIC', 'FINISH', 'CITRUS', 'MOLDY', 'FRESH',
               'EARTHY', 'PUNGENT', 'BERRY', 'BODY', 'FLORAL', 'OTHER', 'PETROLEUM', 'OXIDIZED', 'FLAVOR/DESCRIPTORS',
               'SULFUR', 'BURNED', 'ACIDITY', 'YEASTY', 'NUTTY', 'LACTIC', 'SPICE', 'CANNED/COOKED', 'RESINOUS',
               'CARAMEL', 'TROPICAL FRUIT', 'DRIED FRUIT', 'TANNINS', 'HOT', 'STRUCTURE']
# This is the dataframe for holding the RP category results
df_RP_cate = pd.DataFrame(columns=category, index=winecolR)
# This is the dataframe for holding the RP subcategory results
df_RP_subCat = pd.DataFrame(columns=subcategory, index=winecolR)
# This is the dataframe for holding the WS category results
df_WS_cate = pd.DataFrame(columns=category, index=winecolW)
# This is the dataframe for holding the WS subcategory results
df_WS_subCat = pd.DataFrame(columns=subcategory, index=winecolW)

# This is separating the specific attributes into two category
cols2 = list(set(wName.col_values(2, 1, wName.nrows)))
longWord1 = []
singleWord1 = []
for i in range(len(cols2)):
    if cols2[i].__contains__(" "):
        longWord1.append(cols2[i])
    elif cols2[i].__contains__("-"):
        longWord1.append(cols2[i])
    else:
        singleWord1.append(cols2[i])


# This extract specific name from each comments and write 1 into the attribute result chart;
# and then calculating the category and subcategory values based on the extracted normalized attributes


# This is for RP COMMENT!!!
# These two lists contains the extracted long/short words lists
containLong = []
containShort = []
# These two lists contains the counting of the attributes
wordCountR = []
phraseCountR = []
# RPComment.nrows-1
# for i in range(1, RPComment.nrows - 1):
for i in range(1, RPComment.nrows - 1):
    result1 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    result2 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    a = []  # contain the extracted long words
    b = []  # contain the extracted short words
    d = 0   # word counting
    e = 0   # word counting
    c1 = RPComment.cell_value(i, 3).upper()  # convert the comments into upper case
    if c1.__contains__("RRIES"):
        c1 = c1.replace("RRIES", "RRY")  # replace plurals with singular
    for j in range(len(longWord1)):
        if c1.__contains__(longWord1[j]):
            a.append(longWord1[j])
            c1 = c1.replace(longWord1[j], "")  # delete long words from the comment
            d = d + 1       # counting the extracting long words
            for x in range(1, wName.nrows - 1):
                if longWord1[j] == wName.cell_value(x, 2):
                    df_RP[wName.cell_value(x, 3)].iloc[i - 1] = 1
                    for y in range(len(category)):
                        if category[y] == wName.cell_value(x, 0):
                            result1[y] += 1
                    for d in range(len(subcategory)):
                        if subcategory[d] == wName.cell_value(x, 1):
                            result2[d] += 1

    containLong.append(a)

    c1 = c1.translate(str.maketrans('', '', string.punctuation))
    c1 = c1.translate(str.maketrans('', '', digits))
    c1 = c1.split()
    for g in range(len(singleWord1)):
        if c1.__contains__(singleWord1[g]):
            b.append(singleWord1[g])
            d = d + 1       # adding the counting of single words
            for x in range(1, wName.nrows - 1):
                if singleWord1[g] == wName.cell_value(x, 2):
                    df_RP[wName.cell_value(x, 3)].iloc[i - 1] = 1
                    for y in range(len(category)):
                        if category[y] == wName.cell_value(x, 0):
                            result1[y] += 1
                    for d in range(len(subcategory)):
                        if subcategory[d] == wName.cell_value(x, 1):
                            result2[d] += 1

    containShort.append(b)

    # counting the number of words in the whole comment
    e = len(c1) + len(a)
    # counting the extracting words
    wordCountR.append(d)
    phraseCountR.append(e)

    # calculating the category and subcategory values
    for e in range(len(category)):
        df_RP_cate[category[e]].iloc[i - 1] = result1[e]
    for h in range(len(subcategory)):
        df_RP_subCat[subcategory[h]].iloc[i - 1] = result2[h]

# building the excel sheet for the word counting
attr_RP.insert(0, "PhraseCount", phraseCountR)
attr_RP.insert(1, "ExtractedCount", wordCountR)
attr_RP.insert(2, "Extracted LWords", containLong)
attr_RP.insert(3, "Extracted SWords", containShort)

# print out all the excel sheets -------
# df_RP.to_excel("RP_result.xlsx")
# df_RP_cate.to_excel("RP_cate.xlsx")
# df_RP_subCat.to_excel("RP_subcate.xlsx")
# attr_RP.to_excel("RP_wordcount.xlsx")





# This is for WS COMMENT!!!
containLong1 = []
containShort1 = []
wordCountW = []
phraseCountW = []

for i in range(1, WSComment.nrows - 1):
    a = []  # contain the extracted long words
    b = []  # contain the extracted short words
    d = 0  # word counting
    e = 0  # word counting
    result1 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    result2 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    c1 = WSComment.cell_value(i, 3).upper()  # convert the comments into upper case
    if c1.__contains__("RRIES"):
        c1 = c1.replace("RRIES", "RRY")  # replace plurals with singular
    for j in range(len(longWord1)):
        if c1.__contains__(longWord1[j]):
            a.append(longWord1[j])
            d = d + 1
            c1 = c1.replace(longWord1[j], "")  # delete longwords from the comment
            for x in range(1, wName.nrows - 1):
                if longWord1[j] == wName.cell_value(x, 2):
                    df_WS[wName.cell_value(x, 3)].iloc[i - 1] = 1
                    for y in range(len(category)):
                        if category[y] == wName.cell_value(x, 0):
                            result1[y] += 1
                    for d in range(len(subcategory)):
                        if subcategory[d] == wName.cell_value(x, 1):
                            result2[d] += 1
    containLong1.append(a)

    c1 = c1.translate(str.maketrans('', '', string.punctuation))
    c1 = c1.translate(str.maketrans('', '', digits))
    c1 = c1.split()
    for g in range(len(singleWord1)):
        for h in range(len(c1)):
            if c1[h].__contains__(singleWord1[g]):
                b.append(singleWord1[g])
                d = d + 1
                for x in range(1, wName.nrows - 1):
                    if singleWord1[g] == wName.cell_value(x, 2):
                        df_WS[wName.cell_value(x, 3)].iloc[i - 1] = 1
                        for y in range(len(category)):
                            if category[y] == wName.cell_value(x, 0):
                                result1[y] += 1
                        for d in range(len(subcategory)):
                            if subcategory[d] == wName.cell_value(x, 1):
                                result2[d] += 1
    containShort1.append(b)

    # counting the number of words in the whole comment
    e = len(c1) + len(a)
    # counting the extracting words
    wordCountW.append(d)
    phraseCountW.append(e)

    # calculating the category and subcategory values
    for e in range(len(category)):
        df_WS_cate[category[e]].iloc[i - 1] = result1[e]
    for h in range(len(subcategory)):
        df_WS_subCat[subcategory[h]].iloc[i - 1] = result2[h]

# building the excel sheet for the word counting
attr_WS.insert(0, "PhraseCount", phraseCountW)
attr_WS.insert(1, "ExtractedCount", wordCountW)
attr_WS.insert(2, "Extracted LWords", containLong1)
attr_WS.insert(3, "Extracted SWords", containShort1)

# print out all the excel sheets -------
# df_WS.to_excel("WS_result.xlsx")
# df_WS_cate.to_excel("WS_cate.xlsx")
# df_WS_subCat.to_excel("WS_subcate.xlsx")
# attr_WS.to_excel("WS_wordcount.xlsx")








'''
# this is for calculating the lable 95+/94-
c = 0
a = []
df_RP = pd.DataFrame(columns=[], index=None)
for i in range(1, RPComment.nrows):
    d = []
    if int(RPComment.cell_value(i, 1)) >= 95.0:
        d = 1
        c = c + 1
    else:
        d = 0
    a.append(d)

df_RP.insert(0, "score", a)
df_RP.to_excel("RPscore.xlsx")

c1 = 0
a1 = []
df_WS = pd.DataFrame(columns=[], index=None)
for i in range(1, WSComment.nrows):
    d = []
    if int(WSComment.cell_value(i, 1)) >= 95.0:
        d = 1
        c1 = c1 + 1
    else:
        d = 0
    a1.append(d)

df_WS.insert(0, "score", a1)
df_WS.to_excel("WSscore.xlsx")

'''