# Convert the data from Excel formate to TXT formate

import pip
import xlrd
import xlwt
import pandas as pd
import openpyxl
import string
from string import digits

file = "C:/Users/Flamingo_Hot/PycharmProjects/pythonProject6/train5.xlsx"
df = pd.read_excel(file)
row = len(df.index)
col = len(df.columns)
print(df)

# dataframe is using here to read the excel file! Be careful, it starts from 0, cuz it does not count the header(attribute names) in!
# first part, run through the class lable (score)
with open('train5.txt', 'w') as f:
    for i in range(0, row):
        if int(df.iloc[i,2]) == 0:
            f.write("-1")
            f.write(" ")
        elif int(df.iloc[i,2]) != 0:
            f.write("1")
            f.write(" ")
        # second part, start from category attributes, which is from 3 to 51 columns
        for j in range(3, 51):
            if df.iloc[i,j] == 0.0:
                f.write(str(j-2))
                f.write(":")
                f.write("0")
                f.write(" ")
            else :
                f.write(str(j-2))
                f.write(":")
                f.write(str(df.iloc[i,j]))
                f.write(" ")
        # third part, the normalized attributes, which is from 51 to the end columns
        for k in range(51, col):
            if df.iloc[i,k] == 1:
                f.write(str(k-2))
                f.write(":")
                f.write("1")
                f.write(" ")
            else:
                f.write(str(k-2))
                f.write(":")
                f.write("0")
                f.write(" ")
        f.write("\n")
